(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_b1551a41._.js",
  "static/chunks/node_modules_lodash_034a0376._.js",
  "static/chunks/node_modules_recharts_es6_06f982a3._.js",
  "static/chunks/node_modules_ade0f594._.js"
],
    source: "dynamic"
});
